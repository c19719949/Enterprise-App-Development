Website on the history of the Olympia competition. All images and text were from wikepidia and/or google. 
When I discussed with Luis he said I didn't have to use a tamplate so the entire website 
is of my design. There are multiple extra features on this site, such as tooltips, multiple pages and the 
images in the carousel linking to their corresponding pages. it also has a scrollspy which lets you jump to 
different sections in the main page. This website works and fits on every window size on any device.